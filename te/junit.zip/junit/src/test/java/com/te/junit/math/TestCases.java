package com.te.junit.math;

import org.junit.jupiter.api.Test;

public class TestCases {

	@Test
	public void name() {
		
	}
}
