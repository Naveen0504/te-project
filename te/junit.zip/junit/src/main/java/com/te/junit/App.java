package com.te.junit;

import com.te.junit.math.MathUtil;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		

	}
}
