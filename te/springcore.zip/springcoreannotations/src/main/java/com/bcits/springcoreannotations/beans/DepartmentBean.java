package com.bcits.springcoreannotations.beans;

import lombok.Data;

@Data
public class DepartmentBean {

	private int deptId;
	private String deptName;

}// end of class
