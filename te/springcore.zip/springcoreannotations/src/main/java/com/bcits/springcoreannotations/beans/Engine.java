package com.bcits.springcoreannotations.beans;

import lombok.Data;

@Data
public class Engine {
	private int cc;
	private String type;
}
