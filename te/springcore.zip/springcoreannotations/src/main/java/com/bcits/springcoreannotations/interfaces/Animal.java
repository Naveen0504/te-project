package com.bcits.springcoreannotations.interfaces;

public interface Animal {
	public void eat();

	public void speak();
}
