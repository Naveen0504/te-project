package com.bcits.springcore.beans;

import lombok.Data;

@Data
public class DepartmentBean {
	
	private int deptId;
	private String deptName;
}
