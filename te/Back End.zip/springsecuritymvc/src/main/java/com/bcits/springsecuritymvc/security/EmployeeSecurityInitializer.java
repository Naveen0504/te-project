package com.bcits.springsecuritymvc.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class EmployeeSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}
